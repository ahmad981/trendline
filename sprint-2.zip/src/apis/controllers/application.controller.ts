import { Sequelize } from 'sequelize';
import { JobApplication, JobApplicationInterface } from '../models';

export class JobApplicationController {

  public findAll(): Promise<JobApplication[]> {
    return JobApplication.findAll({});
  }

  public getById(id: number): Promise<JobApplication> {
    return JobApplication.findByPk(id);
  }

  public create(jobapplication: JobApplicationInterface): Promise<JobApplicationInterface> {
    return JobApplication.create<JobApplication>(jobapplication);
  }

  public findByJobId(id: number): Promise<JobApplication> {
    return JobApplication.findOne({ where: { companyId: id } });
  }

  public findByUserId(id: number): Promise<JobApplication> {
    return JobApplication.findOne({ where: { companyId: id } });
  }

  public updateJobApplication(jobapplication: JobApplicationInterface, id: number): Promise<[number, JobApplication[]]> {
    return JobApplication.update(jobapplication, { where: { id } });
  }

  public removeOne(id: number): Promise<number> {
    return JobApplication.destroy({ where: { id } });
  }

  public acceptJobApplication(jobapplication: JobApplicationInterface, id: number): Promise<[number, JobApplication[]]> {
    return JobApplication.update(jobapplication, { where: { id } });
  }

  public rejectJobApplication(jobapplication: JobApplicationInterface, id: number): Promise<[number, JobApplication[]]> {
    return JobApplication.update(jobapplication, { where: { id } });
  }

  public cancelJobApplication(jobapplication: JobApplicationInterface, id: number): Promise<[number, JobApplication[]]> {
    return JobApplication.update(jobapplication, { where: { id } });
  }

  public getJobsByHour(hours: number) : Promise<JobApplicationInterface[]> {
    return JobApplication.findAll({
      where: {
        'createdAt':{
          $gt: Sequelize.fn(
            'DATE_SUB',
            Sequelize.literal('NOW()'),
            Sequelize.literal(`INTERVAL ${hours} HOUR`),
          ),
        },
      },
    });
  }
}
