export const trTypes = [
  {id: 1, title: 'Job Shadow'},
  {id: 2, title: 'Internship'},
  {id: 3, title: 'Consulting Project'},
  {id: 4, title: 'Career Mentoring'},
  {id: 5, title: 'Boot Camp'},
  {id: 6, title: 'Pre-Aprenticeship'},
  {id: 7, title: 'Aprenticeship'},
];