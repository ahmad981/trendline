interface PaginationInterface {
  total?: number;
  page?: number ;
  limit?: number;
  offset?: number;
}

export {PaginationInterface};